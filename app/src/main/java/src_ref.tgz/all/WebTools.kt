package com.example.agentapp

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * WebTools: 网页抓取工具。
 * 直接使用手机本地网络抓取网页, 提取正文文本, 限长返回。
 * 不依赖 SSH/远端, 手机有网即可用。
 */
object WebTools {

    private const val DEFAULT_MAX_CHARS = 3000
    private const val MAX_BYTES = 2 * 1024 * 1024 // 最多下载 2MB, 防拉爆流量
    private const val CONNECT_TIMEOUT = 15000
    private const val READ_TIMEOUT = 30000
    private val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"
    // Bing 搜索用桌面 UA: 移动 UA 下 cn.bing.com 返回非标准结构, 无法解析
    private val SEARCH_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    /**
     * 参数: {"q":"搜索关键词","max_results":5}
     * 返回: Bing 搜索结果(标题+链接+摘要), 最多 max_results 条
     */
    fun search(arg: String): String {
        val json = try { JSONObject(arg) } catch (e: Exception) { null }
        val query = json?.optString("q")?.takeIf { it.isNotBlank() } ?: arg.trim()
        val maxResults = (json?.optInt("max_results", 5) ?: 5).coerceIn(1, 10)
        if (query.isBlank()) return "错误: 搜索关键词为空"
        if (!query.matches(Regex("[\\s\\S]{1,200}"))) return "错误: 关键词过长"
        val url = "https://cn.bing.com/search?q=" + URLEncoder.encode(query, "UTF-8")
        return try {
            val raw = download(url, SEARCH_UA) ?: return "错误: 搜索失败(超时或网络不可用)"
            parseResults(raw, maxResults)
        } catch (e: Exception) {
            "错误: ${e.message}"
        }
    }

    /** 解析 Bing 结果页 li.b_algo 块 */
    private fun parseResults(html: String, maxResults: Int): String {
        val blocks = Regex("(?is)<li class=\"b_algo\".*?</li>").findAll(html).take(maxResults).toList()
        if (blocks.isEmpty()) return "未找到搜索结果"
        val sb = StringBuilder()
        var idx = 0
        for (b in blocks) {
            val m = b.value
            val link = Regex("(?is)<h2[^>]*><a[^>]*href=\"([^\"]+)\"").find(m)?.groupValues?.get(1)
            val title = Regex("(?is)<h2[^>]*>.*?<a[^>]*>(.*?)</a>").find(m)?.groupValues?.get(1)
                ?.replace(Regex("<[^>]+>"), "")?.trim()
            val snippet = Regex("(?is)<p[^>]*>(.*?)</p>").find(m)?.groupValues?.get(1)
                ?.replace(Regex("<[^>]+>"), "")?.trim()
            if (link != null) {
                idx++
                sb.append("$idx. ${title ?: "(无标题)"}\n   $link\n   ${snippet ?: ""}\n")
            }
        }
        return if (sb.isEmpty()) "未找到可解析的搜索结果" else sb.toString().trim()
    }

    /**
     * 参数: {"url":"https://...","max_chars":3000}
     * 返回: 提取后的网页正文文本(截断到 max_chars)
     */
    fun fetch(arg: String): String {
        val json = try { JSONObject(arg) } catch (e: Exception) { null }
        val url = json?.optString("url")?.takeIf { it.isNotBlank() } ?: arg.trim()
        val maxChars = json?.optInt("max_chars", DEFAULT_MAX_CHARS) ?: DEFAULT_MAX_CHARS
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            return "错误: URL必须以http://或https://开头"
        }
        return try {
            val raw = download(url) ?: return "错误: 下载失败(超时或网络不可用)"
            val text = extractText(raw)
            val cleaned = text.replace(Regex("\\s+"), " ").trim()
            if (cleaned.isEmpty()) return "网页无可见文本(可能是JS渲染页面, 建议用浏览器查看)"
            if (cleaned.length > maxChars) cleaned.substring(0, maxChars) + "\n...[已截断]" else cleaned
        } catch (e: Exception) {
            "错误: ${e.message}"
        }
    }

    private fun download(url: String, ua: String = UA): String? {
        var current = url
        var redirects = 0
        while (redirects <= 5) {
            val conn = URL(current).openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.setRequestProperty("User-Agent", ua)
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,*/*;q=0.8")
            conn.connectTimeout = CONNECT_TIMEOUT
            conn.readTimeout = READ_TIMEOUT
            conn.instanceFollowRedirects = false
            val code = conn.responseCode
            if (code in 300..399) {
                val loc = conn.getHeaderField("Location") ?: return null
                conn.disconnect()
                current = if (loc.startsWith("http")) loc else {
                    val base = URL(current)
                    URL(base, loc).toString()
                }
                redirects++
                continue
            }
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            if (stream == null) { conn.disconnect(); return null }
            val sb = StringBuilder()
            val buf = ByteArray(8192)
            var total = 0
            stream.use { ins ->
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_BYTES) break
                    sb.append(String(buf, 0, n, Charsets.UTF_8))
                }
            }
            conn.disconnect()
            return if (total > MAX_BYTES) sb.toString() + "\n[下载超过2MB已截断]" else sb.toString()
        }
        return null
    }

    /** 粗略HTML转文本: 去script/style/标签, 解码实体, 保留标题 */
    private fun extractText(html: String): String {
        val title = Regex("(?is)<title[^>]*>(.*?)</title>").find(html)?.groupValues?.get(1)?.trim().orEmpty()
        var s = html
        s = s.replace(Regex("(?is)<(script|style|noscript)[^>]*>.*?</\\1>"), " ")
        s = s.replace(Regex("(?is)<br\\s*/?>"), "\n")
        s = s.replace(Regex("(?is)</(p|div|h[1-6]|li|tr)>"), "\n")
        s = s.replace(Regex("(?s)<[^>]+>"), " ")
        s = s.replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<")
            .replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'")
            .replace("&apos;", "'")
        return if (title.isNotEmpty()) "标题: $title\n$s" else s
    }
}
